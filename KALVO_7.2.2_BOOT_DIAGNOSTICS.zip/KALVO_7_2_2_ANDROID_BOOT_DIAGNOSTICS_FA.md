# وضعیت KALVO 7.2.2 — تشخیص کرش شروع اندروید

## چرا نسخهٔ جدید ساخته شد؟

نسخهٔ 7.2.1 روی گوشی گزارش‌شده همچنان روی splash بومی Kivy می‌ماند و سپس بسته می‌شود. تغییرات صوت و lazy screen به‌تنهایی کافی نبودند. در نتیجه علت runtime هنوز اثبات نشده است.

## تغییرات تشخیصی

- ثبت trace مرحله‌ای از ورود `main.py` و importهای Kivy/APEX تا آماده‌شدن رابط اصلی.
- ثبت استثنای Python با نام آخرین مرحله در `startup-crash.log`.
- ثبت وضعیت شروع ساخت دیتابیس، Dashboard، Navigation، `build()` و `on_start()`.
- تأخیر در شروع درخواست‌های شبکهٔ داشبورد تا ۲٫۵ ثانیه و چرخهٔ اولیهٔ position supervisor تا ۸ ثانیه برای جداسازی cold-start از کارهای پس‌زمینه.
- presplash بومی Kivy دست‌نخورده است؛ فقط نشانگر پیش از آماده‌شدن Python/UI است و خودش علت شناخته‌شدهٔ کرش نیست.

## مسیر گزارش

داخل فضای خصوصی برنامه:

- `.kalvo/logs/startup-trace.log`
- `.kalvo/logs/startup-crash.log`

اگر trace تولید نشد، احتمال خطای پیش از ورود Python یا native وجود دارد و Android Bug Report / logcat لازم است.

## تست‌ها و محدودیت‌ها

- Pytest: 249 passed, 33 subtests passed.
- Unittest: 241 tests passed.
- Compileall: موفق.
- این تست‌ها ایستا/واحدی هستند و اجرای واقعی روی گوشی را ثابت نمی‌کنند.
- در محیط محلی، Kivy و Android SDK/NDK نصب نیست؛ APK این نسخه در این محیط ساخته و روی دستگاه فیزیکی اجرا نشده است.
